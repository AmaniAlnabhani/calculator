package com.amani.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button Add =(Button) findViewById(R.id.Add);
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText num1 =(EditText) findViewById(R.id.FirstNumber);
                EditText num2 =(EditText) findViewById(R.id.SecondNumber);
                TextView result =(TextView)findViewById(R.id.result);
                int n1 =Integer.parseInt(num1.getText().toString());
                int n2 =Integer.parseInt(num2.getText().toString());
                int sum= n1+n2;
                result.setText(sum+" ");
            }
        });

      Button Subtraction=(Button)findViewById(R.id.Subtraction);
        Subtraction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText num1 =(EditText) findViewById(R.id.FirstNumber);
                EditText num2 =(EditText) findViewById(R.id.SecondNumber);
                TextView result =(TextView)findViewById(R.id.result);
                int n1 =Integer.parseInt(num1.getText().toString());
                int n2 =Integer.parseInt(num2.getText().toString());
                int sub= n1 -n2;
                result.setText(sub+" ");
            }
        });
        Button Multiplication= (Button)findViewById(R.id.Multiplication);
        Multiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText num1 =(EditText) findViewById(R.id.FirstNumber);
                EditText num2 =(EditText) findViewById(R.id.SecondNumber);
                TextView result =(TextView)findViewById(R.id.result);
                int n1 =Integer.parseInt(num1.getText().toString());
                int n2 =Integer.parseInt(num2.getText().toString());
                int mul= n1 * n2;
                result.setText(mul+" ");
            }
        });
        Button Division= (Button)findViewById(R.id.Division);
        Division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText num1 =(EditText) findViewById(R.id.FirstNumber);
                EditText num2 =(EditText) findViewById(R.id.SecondNumber);
                TextView result =(TextView)findViewById(R.id.result);
                double n1 =Double.parseDouble(num1.getText().toString());
                double n2 =Double.parseDouble(num2.getText().toString());
                double div= n1 / n2;
                result.setText(div+" ");
            }
        });
    }
}
